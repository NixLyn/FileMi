from setuptools import setup

setup(
    name='filemi',
    version='1.0',
    description='A file management utility package',
    author='Your Name',
    author_email='dillon.nyxlyn@gmail.com',
    packages=['File_Mi'],
)
