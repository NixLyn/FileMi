class FileMiError(Exception):
    pass
   
